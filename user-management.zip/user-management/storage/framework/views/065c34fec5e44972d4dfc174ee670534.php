<div class="flex flex-1">
				<a href="<?php echo e(route('users.edit', [auth()->id()])); ?>" class="btn btn-primary">Profile Update</a>
				<?php if(auth()->user()->role == 'administrator'): ?>
								<a href="<?php echo e(route('users.create')); ?>" class="btn btn-primary">Create User</a>
								<a href="<?php echo e(route('users.index')); ?>" class="btn btn-primary">User Listing</a>
				<?php endif; ?>

</div>
<?php /**PATH D:\xampp\htdocs\user-management\resources\views/users/links.blade.php ENDPATH**/ ?>