

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header"><?php echo e(__('Dashboard')); ?></div>

                <?php echo $__env->make('users.links', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                <div class="card-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                        
                    <?php endif; ?>
                    <table class="table">
                        <thead>
                          <tr>
                            <th scope="col">#</th>
                            <th scope="col">Name</th>
                            <th scope="col">Email</th>
                            <th scope="col">Role</th>
                            <th scope="col">Action</th>
                          </tr>
                        </thead>
                        <tbody>
                            <?php if($users->total()>0): ?>
                            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <th scope="row"><?php echo e($user->id); ?></th>
                                <td><?php echo e($user->name); ?></td>
                                <td><?php echo e($user->email); ?></td>
                                <td><?php echo e(ucfirst($user->role)); ?></td>
                                <td>
                                    <div >
                                    <a href="<?php echo e(route('users.edit', [$user->id])); ?>?page=<?php echo e(request('page')); ?>" class="">
                                        <img
                                            src="assets/img/icons/edit.svg" alt="img" class="icon-adjustment">
                                    </a>
                                    <form id="pdelete_from_<?php echo e($user->id); ?>" action="<?php echo e(route('users.destroy', $user->id)); ?>" method="post" class="d-inline">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <input type="hidden" name="page" id="page" value="<?php echo e(request('page')); ?>">
                                        

                                        <a href="javascript:void(0);"  data-bs-toggle="tooltip" data-bs-placement="top" title="User deleted">
                                            <img
                                            src="assets/img/icons/delete.svg" alt="img" class="icon-adjustment _delete_p" data-id="<?php echo e($user->id); ?>">
                                        </a>  

                                    </form>
                                </div>
                                </td>
                              </tr>

                            
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          
                            <?php else: ?>
                            <tr>
                                
                                <td colspan="4">No record found</td>
                                
                              </tr>

                              <?php endif; ?>
                        </tbody>
                      </table>
                      <div class="container">
                        <?php echo e($users->onEachSide(5)->links()); ?>

                      </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\user-management\resources\views/users/index.blade.php ENDPATH**/ ?>